<?php
// Clave para entrar a la administración de mensajes:
//   index.php?c=contacto&a=entrar
// Cámbiala por una clave larga y propia. Mientras diga CAMBIA_ESTA_CLAVE el acceso queda bloqueado.
// Si subes el proyecto a GitHub, agrega "config/admin.php" a .gitignore (igual que config.php).
return [
    'clave' => 'CAMBIA_ESTA_CLAVE',
];
